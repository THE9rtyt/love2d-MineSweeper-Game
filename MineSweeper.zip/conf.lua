-- Configuration
function love.conf(t)
    t.title = "MineSweeper"
    t.version = "11.3"
    t.window.minwidth = 500
    t.window.minheight = 570
    t.window.resizable = true
end